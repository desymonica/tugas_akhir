<?php
$options = array("stnk" => "Kehilangan STNK", "ktp" => "Kehilangan KTP", "sim" => "Kehilangan SIM");

if (isset($_POST['jenisPengaduan'])) {
  switch ($_POST['jenisPengaduan']) {
    case 'stnk':
      header('Location: ' . 'http://localhost/terserah/pengaduan/halaman/stnk.php');
      break;
    case 'ktp':
      header('Location: ' . 'http://localhost/terserah/pengaduan/halaman/ktp.php');
      break;
    case 'sim':
      header('Location: ' . 'http://localhost/terserah/pengaduan/halaman/sim.php');
      break;
    default:
      break;
  }
}

?>

<!DOCTYPE html>
<html>

<head>
  <title>Form Pelaporan</title>
</head>

<body>
  <h1 align='center'>Form Pelaporan</h1>
  <div id='mainform'>
    <form id='frm_vld' method='post' name='frm_vld'>
      <h3 align='center'>Silahkan mengisi form dibawah ini</h3>
      <!-- <table align='center' cellpadding='5' cellspacing='5'> -->
      <table>
        <tr>
          <td>Nama Pelapor</td>
          <td>:</td>
          <td><input name='name' /></td>
        </tr>
        <tr>
          <td>Alamat</td>
          <td>:</td>
          <td><input name='address' /></td>
        </tr>
        <tr>
          <td>No.Telp</td>
          <td>:</td>
          <td><input type='number' name='tel' /></td>
        </tr>
        <tr>
          <td>E-mail</td>
          <td>:</td>
          <td><input type='email' name='email'></td>
        </tr>
        <tr>
          <td>Laporan</td>
          <td>:</td>
          <td>
            <?php
            foreach ($options as $key => $value) {
              echo "<input type=\"radio\" name=\"jenisPengaduan\" required value=\"$key\">
                  <label>$value</label><br>";
            }
            ?>
          </td>
        </tr>
        <tr>
          <td><input type='submit' name='submit' value='Submit'></td>
          <td></td>
          <td><input type='reset' name='reset' value='Reset'></td>
        </tr>
      </table>
    </form>
  </div>
</body>

</html>