<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Berkas Kehilangan KTP</title>
  <!-- menghubungkan dengan file css -->
  <link rel="stylesheet" type="text/css" href="/terserah/pengaduan/style.css">
  <!-- menghubungkan dengan file jquery -->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
</head>

<body>
  <div class="content">
    <header>
      <h1 class="judul">Formulir Sektor Kepolisian</h1>
      <center>
        <h6 class="deskripsi">Kepolisian Sektor Jakarta Barat | Jakarta | 021-76445 | www.polsekjakartabarat</h6>
      </center>
    </header>

    <div class="menu">
      <ul>
        <li><a href="index.php?page=home">HOME</a></li>
        <li><a href="index.php?page=pengaduan">PENGADUAN</a></li>
        <li><a href="index.php?page=pembayaran">PEMBAYARAN</a></li>
        <li><a href="index.php?page=tentang">TENTANG</a></li>
      </ul>
    </div>

    <h1 align='center'>Kantor Polisi Sektor Jakarta Barat</h1>
    <div class="badan">

      <h3 align='center'>Silakan Lengkapi berkas dibawah ini</h3>

      <h3>Berkas Kehilangan KTP</h3>

      <div>
        Berikut Berkas-berkas yang perlu dilengkapi untuk memenuhi syarat pelaporan : <br><br>
					1. Surat kehilangan e-KTP dari kantor kepolisian <br>
					2. Surat pengantar dari keluarahan<br>
					3. Formulir permohonan e-KTP baru dari keluarahan<br> 
					4. Untuk kasus KTP rusak, tidak perlu surat keterangan kehilangan dari kepolisian, cukup bawa bukti KTP yang rusak saja<br>
					5. Pas foto ukuran 3x4 sebanyak 2 lembar untuk dibawa ke kantor kelurahan<br> 
					*Latar belakang warna merah untuk tahun kelahiran ganjil dan warna biru untuk tahun kelahiran genap. 
					6. Pas foto ukuran 4x6 sebanyak 2 lembar, dibawa ke kantor kecamatan dengan latar belakang warna merah untuk tahun kelahiran ganjil dan warna biru untuk tahun kelahiran genap<br> 
					7. Fotokopi kartu keluarga<br><br><br>
      </div>

    </div>
  </div>
</body>

</html>