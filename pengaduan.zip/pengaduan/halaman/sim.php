<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Berkas Kehilangan SIM</title>
  <!-- menghubungkan dengan file css -->
  <link rel="stylesheet" type="text/css" href="/terserah/pengaduan/style.css">
  <!-- menghubungkan dengan file jquery -->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
</head>

<body>
  <div class="content">
    <header>
      <h1 class="judul">Formulir Sektor Kepolisian</h1>
      <center>
        <h6 class="deskripsi">Kepolisian Sektor Jakarta Barat | Jakarta | 021-76445 | www.polsekjakartabarat</h6>
      </center>
    </header>

    <div class="menu">
      <ul>
        <li><a href="index.php?page=home">HOME</a></li>
        <li><a href="index.php?page=pengaduan">PENGADUAN</a></li>
        <li><a href="index.php?page=pembayaran">PEMBAYARAN</a></li>
        <li><a href="index.php?page=tentang">TENTANG</a></li>
      </ul>
    </div>

    <h1 align='center'>Kantor Polisi Sektor Jakarta Barat</h1>
    <div class="badan">

      <h3 align='center'>Silakan Lengkapi berkas dibawah ini</h3>

      <h3>Berkas Kehilangan SIM</h3>

      <div>
        Berikut Berkas-berkas yang perlu dilengkapi untuk memenuhi syarat pelaporan : <br><br>
        1. Surat Kehilangan dari Kantor Kepolisian <br>
        2. KTP Asli dan Fotocopy KTP <br>
        3. Fotocopy SIM lama (jika ada) <br>
      </div>

    </div>
  </div>
</body>

</html>