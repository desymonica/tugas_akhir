<?php

$nama = $_POST['nama'] ?? '';
$nomor = $_POST['nomor'] ?? '';
$total = $_POST['total'] ?? '';

class Pembayaran
{
  private $name;
  private $nomor;
  private $total;

  function __construct($nama, $nomor, $total)
  {
    $this->nama = $nama;
    $this->nomor = $nomor;
    $this->total = $total;
  }

  function get_name()
  {
    return $this->nama;
  }
  function get_nomor()
  {
    return $this->nomor;
  }
  function get_total()
  {
    return $this->total;
  }
}

$pembayaran = new Pembayaran($nama, $nomor, $total);

?>

<html leng="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Form Pembayaran</title>

  <head>

  <body>
    <header>
      <h2 class="text-center">
        Form Pembayaran
      </h2>
    </header>
    <div class="wrapper">

      <h2 class="container-header text-center">Pendataan Formulir Pembayaran</h2>

      <div class="container">

        <form class="form" method="post" id="form">
          <div class="form-group form-book">
            <label for="nama">Nama Pelapor</label>
            <input id="nama" name="nama" required>
          </div>
          <div class="form-group form-book">
            <label for="nomor">Nomor Telepon</label>
            <input type="number" id="nomor" name="nomor" required>
          </div>
          <div class="form-group form-book">
            <label for="total">Total Pembayaran</label>
            <input type="number" id="total" name="total" required>
          </div>

          <button type="submit" class="btn-submit">Submit</button>
        </form>

      </div>

    </div>

    <script>
      <?php
      if ($nama && $nomor && $total) {
        echo "alert(\"Terima kasih " . $pembayaran->get_name() . " karena sudah membayar dengan total " . $pembayaran->get_total() . "\")";
      }
      ?>
    </script>
  </body>

</html>