<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Kantor Polisi Sektor Jakarta Barat</title>
</head>
<body>
	<div class="halaman">
		<h2>Kantor Polisi Sektor Jakarta Barat</h2><br>
		<img src="polres.jpg" height="300px" width="500px;">
		<p>
		Visi<br>
		Terwujudnya Polda Metro Jaya yang Transparan dan Akuntabel<br><br>
		Misi<br>
		Menjamin kualitas kinerja dan anggaran Polda<br>
		Meningkatkan Kapabilitas APIP Polda. </p>
		<p class="justify">
			Tugas & Fungsi
	Tugas dan Fungsi Itwasda Polda Metro Jaya diatur dalam Peraturan Kepolisian Negara Republik Negara Indonesia Nomor 14 Tahun 2018 tentang Susunan Organisasi dan Tata Kerja pada tingkat Polda dan jabaran tugas dan fungsi Itwasda Polda Metro Jaya di atur dalam Peraturan Irwasda Polda Metro Jaya Nomor 1 Tahun 2012 tentang Hubungan dan Tata Cara Kerja di lingkungan Itwasda Polda Metro Jaya, serta Keputusan Irwasda Polda Metro Jaya Nomor: Kep/07/XII/2014 tanggal 24 Desember 2014 tentang Analisis Beban Kerja di lingkungan Inspektorat Pengawasan Daerah.<br>

	1.TUGAS : Menyelenggarakan pengawasan di lingkungan Polda untuk memberikan penjaminan kualitas dan memberikan konsultasi serta 			  pendampingan kegiatan pengawasan dari lembaga eksternal.<br>

	2.FUNGSI : <br>
	a.Penyusunan rencana kerja dan anggaran, pengelolaan dan pembinaan manajemen personel dan logistik, administrasi dan ketatausahaan, serta pengelolaan keuangan; <br>
	b.Pengawasan untuk memberikan penjaminan kualitas dengan cara:<br> 
	1)Audit penyelenggaraan manajemen di bidang operasional, Sumber Daya Manusia (SDM), logistik dan anggaran keuangan (Garkeu);<br>
	2)Reviu; <br>
	3)Pemantauan Tindak Lanjut (PTL); dan <br>
	4)Evaluasi. <br>
	c.Pemberian konsultasi, sosialisasi, dan asistensi; <br>
	d.Penyusunan dan perumusan kebijakan di bidang pengawasan; <br>
	e.Penanganan pengaduan masyarakat yang disampaikan oleh instansi, masyarakat atau pegawai negeri pada Polri; dan <br>
	f.Pendampingan kegiatan pengawasan dari Lembaga pengawas eksternal. Berdasarkan Keputusan Irwasda Polda Metro Jaya Nomor: Kep/05/XII/2019 tanggal 31 Desember 2019 tentang Rancangan Rencana Strategis Inspektur Pengawasan Daerah Polda Metro Jaya tahun 2020-2024.
		</p>
	</div>
</body>
</html>