<!DOCTYPE html>
<html>

<head>
  <title>Formulir Sektor Kepolisian</title>
  <!-- menghubungkan dengan file css -->
  <link rel="stylesheet" type="text/css" href="style.css">
  <!-- menghubungkan dengan file jquery -->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
</head>

<body>


  <div class="content">
    <header>
      <h1 class="judul">Formulir Sektor Kepolisian</h1>
      <center>
        <h6 class="deskripsi">Kepolisian Sektor Jakarta Barat | Jakarta | 021-76445 | www.polsekjakartabarat</h6>
      </center>
    </header>

    <div class="menu">
      <ul>
        <li><a href="index.php?page=home">HOME</a></li>
        <li><a href="index.php?page=pengaduan">PENGADUAN</a></li>
        <li><a href="index.php?page=pembayaran">PEMBAYARAN</a></li>
        <li><a href="index.php?page=tentang">TENTANG</a></li>
      </ul>
    </div>

    <div class="badan">


      <?php
      if (isset($_GET['page'])) {
        $page = $_GET['page'];

        switch ($page) {
          case 'home':
            include "halaman/home.php";
            break;
          case 'pembayaran':
            include "halaman/pembayaran.php";
            break;
          case 'tentang':
            include "halaman/tentang.php";
            break;
          case 'pengaduan':
            include "halaman/pengaduan.php";
            break;
          default:
            echo "<center><h3>Maaf. Halaman tidak di temukan !</h3></center>";
            break;
        }
      } else {
        include "halaman/home.php";
      }

      ?>

    </div>
  </div>
</body>

</html>